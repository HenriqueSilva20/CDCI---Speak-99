---
title: Arrow left square
layout: icon
categories:
  - Shape Arrows
tags:
  - arrow
  - square
---
