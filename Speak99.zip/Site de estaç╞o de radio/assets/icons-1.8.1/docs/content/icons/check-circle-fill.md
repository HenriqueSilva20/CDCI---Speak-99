---
title: Check circle fill
layout: icon
categories:
  - Alerts, warnings, and signs
tags:
  - checkmark
  - confirm
  - done
---
