---
title: Clipboard2 fill
categories:
  - Real world
tags:
  - copy
  - paste
---
