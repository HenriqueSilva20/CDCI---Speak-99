---
title: Bar chart fill
categories:
  - Data
tags:
  - chart
  - graph
  - analytics
---
